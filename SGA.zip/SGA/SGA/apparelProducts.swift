//
//  apparelProducts.swift
//  SGA
//
//  Created by SASIKUMAR on 03/10/23.
//

import UIKit

class apparelProducts: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var selectedProduct: ApparelProduct?

    @IBOutlet weak var myTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.myTable.delegate = self
        self.myTable.dataSource = self
        myTable.rowHeight = 300
    }
    
    @IBAction func user(_ sender: Any) {
        let push = storyboard?.instantiateViewController(withIdentifier: "user") as! user
        
        navigationController?.pushViewController(push, animated: true)
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apparelProducts.count
       }

       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "productCell", for: indexPath) as! productCell
           let product = apparelProducts[indexPath.row]

           // Configure the cell with product data
           cell.namelabel.text = product.name
           cell.descriptionlabel.text = product.description
           cell.pricelabel.text = "$\(product.price)"
           
           cell.imageone.image = UIImage(named: product.imageURL)
          

           return cell
       }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedProduct = apparelProducts[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "productCell", for: indexPath) as! productCell
           // Create an instance of the next view controller
           if let nextViewController = storyboard?.instantiateViewController(withIdentifier: "cartViewcontroller") as? cartViewcontroller {
               // Pass the selected ApparelProduct to the next view controller
              
               nextViewController.product = selectedProduct
              
               
             
               // Push the next view controller onto the navigation stack
               navigationController?.pushViewController(nextViewController, animated: true)
           }
            }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Handle the deletion here
            // Remove the item from your data source (e.g., your apparelProducts array)
            apparelProducts.remove(at: indexPath.row)
            
            // Delete the row from the table view
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    
    
    struct ApparelProduct {
        var name: String
        var description: String
        var price: Double
        var imageURL: String
       
    }
    var apparelProducts = [
        ApparelProduct(name: "T-shirt 1", description: "Comfortable cotton T-shirt", price: 20.0, imageURL: "Image.jpg"),
        ApparelProduct(name: "Jeans 1", description: "Stylish denim jeans", price: 40.0, imageURL: "Image 1.jpg"),
        ApparelProduct(name: "T-shirt 2", description: "Comfortable cotton T-shirt", price: 20.0, imageURL: "Image 2.jpg"),
        ApparelProduct(name: "Jeans 2", description: "Stylish denim jeans", price: 40.0, imageURL: "Image 3.jpg"),
        // Add more products as needed
        ApparelProduct(name: "T-shirt 20", description: "Comfortable cotton T-shirt", price: 20.0, imageURL: "Image 4.jpg"),
        ApparelProduct(name: "Jeans 20", description: "Stylish denim jeans", price: 40.0, imageURL: "Image 5.jpg"),
    ]


}
