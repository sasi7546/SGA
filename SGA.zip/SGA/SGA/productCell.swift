//
//  productCell.swift
//  SGA
//
//  Created by SASIKUMAR on 03/10/23.
//

import UIKit

class productCell: UITableViewCell {

    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var totalitem: UILabel!
    @IBOutlet weak var imageone: UIImageView!
    @IBOutlet weak var pricelabel: UILabel!
    @IBOutlet weak var descriptionlabel: UILabel!
    @IBOutlet weak var namelabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        totalitem.text = "\(Int(stepper.value))"
        
        // Configure the view for the selected state
    }
    
    @IBAction func additem(_ sender: UIStepper) {
        totalitem.text = "\(Int(sender.value))"
    }
    
   

}
