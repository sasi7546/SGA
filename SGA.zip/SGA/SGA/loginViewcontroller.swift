//
//  loginViewcontroller.swift
//  SGA
//
//  Created by SASIKUMAR on 03/10/23.
//

import UIKit
import Firebase
import FirebaseAuth

class loginViewcontroller: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var paaswordTextfield: UITextField!
    @IBOutlet weak var phoneNoTextfiled: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.bounds
        
        // Define your gradient colors
        gradientLayer.colors = [UIColor.red.cgColor, UIColor.blue.cgColor] // Example colors
        
        // Define gradient direction (optional)
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 1.0)
        
        // Add the gradient layer to your view's layer
        view.layer.insertSublayer(gradientLayer, at: 0)
        
        self.phoneNoTextfiled.layer.borderColor = UIColor.black.cgColor
        self.paaswordTextfield.layer.borderColor = UIColor.black.cgColor
        
        
        self.phoneNoTextfiled.layer.masksToBounds = true
        self.phoneNoTextfiled.layer.masksToBounds = true
        
    }
    
    @IBAction func sendOtp(_ sender: Any) {
        let phoneNumber = phoneNoTextfiled.text! // Replace with the user's phone number
        sendOTP(to: phoneNumber) { error in
            if let error = error {
                print("Error sending OTP: \(error.localizedDescription)")
                // Handle the error (e.g., show an alert)
            } else {
                // OTP sent successfully, proceed to verification
                // Navigate to the verification screen where the user can enter the OTP
            }
        }
        
    }
    func sendOTP(to phoneNumber: String, completion: @escaping (Error?) -> Void) {
        PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber, uiDelegate: nil) { verificationID, error in
            if let error = error {
                completion(error)
                return
            }
            // Store verificationID securely for later use (e.g., in UserDefaults)
            UserDefaults.standard.set(verificationID, forKey: "verificationID")
            completion(nil)
        }
    }
    func verifyOTP(_ otp: String, completion: @escaping (Error?) -> Void) {
        guard let verificationID = UserDefaults.standard.string(forKey: "verificationID") else {
            // Handle the case where verificationID is not found (e.g., show an alert)
            return
        }
        
        let credential = PhoneAuthProvider.provider().credential(withVerificationID: verificationID, verificationCode: otp)
        Auth.auth().signIn(with: credential) { _, error in
            if let error = error {
                completion(error)
            } else {
                // Successful verification, user is now authenticated
              
                completion(nil)
            }
        }
    }
    
    
    
    
    @IBAction func verifyOtp(_ sender: Any) {
        if let phoneNumber = paaswordTextfield.text {
            verifyOTP(phoneNumber) { error in
                if let error = error {
                    print("Error verifying OTP: \(error.localizedDescription)")
                    // Handle the verification error (e.g., show an alert)
                } else {
                    // OTP verification successful, proceed to the next screen or action
                    // For example, you can navigate to the user's dashboard
                    // or perform any other action as needed
                    UserDefaults.standard.set(self.phoneNoTextfiled.text!, forKey: "userMobileNumber")
                    print("verifyOTP SUCCESSFUL")
                }
            }
        } else {
            // Handle the case where the phone number text field is empty
        }
        
    }
}
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


