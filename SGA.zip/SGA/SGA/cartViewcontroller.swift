//
//  cartViewcontroller.swift
//  SGA
//
//  Created by SASIKUMAR on 03/10/23.
//

import UIKit

class cartViewcontroller: UIViewController {
    var product: apparelProducts.ApparelProduct?
    var totalcart = String()
   
    @IBOutlet weak var IMAGE: UIImageView!
    @IBOutlet weak var DESCRIPTION: UILabel!
    @IBOutlet weak var PRICE: UILabel!
    @IBOutlet weak var NAME: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
     //   self.NAME.text = "\(products.name)"
        if let product = product {
                    NAME.text = product.name
                    DESCRIPTION.text = product.description
                    PRICE.text = "$\(product.price)"
                    // Load the image from imageURL and set it to the imageView
          
                    IMAGE.image = UIImage(named: product.imageURL)
           
                }
      
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
