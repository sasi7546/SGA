//
//  ViewController.swift
//  SGA
//
//  Created by SASIKUMAR on 03/10/23.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {
    @IBOutlet weak var Map: MKMapView!
    
    var startCoordinate: CLLocationCoordinate2D?
        var endCoordinate: CLLocationCoordinate2D?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
   
        
        let inputString = "Hello World Swift"
        var words: [Character] = []
        var currentWord: [Character] = []

        for char in inputString {
            if char == " " {
                words += currentWord.reversed()
                words.append(" ")
                currentWord.removeAll()
            } else {
                currentWord.append(char)
            }
        }

        // Add the last word (if any) after the loop
        words += currentWord.reversed()

        let reversedString = String(words)
        print(reversedString)

        
        
        
        Map.delegate = self
               let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        Map.addGestureRecognizer(longPressGesture)
        

    }
    @objc func handleLongPress(_ gestureRecognizer: UILongPressGestureRecognizer) {
            if gestureRecognizer.state == .began {
                let touchPoint = gestureRecognizer.location(in: Map)
                let coordinate = Map.convert(touchPoint, toCoordinateFrom: Map)
                if startCoordinate == nil {
                    startCoordinate = coordinate
                    // Add a pin for the start point
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = coordinate
                    annotation.title = "Start Point"
                    Map.addAnnotation(annotation)
                } else if endCoordinate == nil {
                    endCoordinate = coordinate
                    // Add a pin for the end point
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = coordinate
                    annotation.title = "End Point"
                    Map.addAnnotation(annotation)
                    // Calculate and show distance
                    if let distance = calculateDistance() {
                        let alertController = UIAlertController(title: "Distance", message: "Distance: \(distance) Kilometer", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        present(alertController, animated: true, completion: nil)
                    }
                } else {
                    // Ask the user if they want to change the start point
                    showChangeStartPointAlert()
                }
            }
        }

    func calculateDistance() -> CLLocationDistance? {
        guard let start = startCoordinate, let end = endCoordinate else {
            return nil
        }
        let startLocation = CLLocation(latitude: start.latitude, longitude: start.longitude)
        let endLocation = CLLocation(latitude: end.latitude, longitude: end.longitude)
        
        // Calculate the distance in meters
        let distanceInMeters = startLocation.distance(from: endLocation)
        
        // Convert meters to kilometers
        let distanceInKilometers = distanceInMeters / 1000.0
        
        return distanceInKilometers
    }


        func showChangeStartPointAlert() {
            let alertController = UIAlertController(title: "Change Start Point", message: "Do you want to change the start point?", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            alertController.addAction(UIAlertAction(title: "Change", style: .default, handler: { (_) in
                // Reset start and end coordinates
                self.startCoordinate = nil
                self.endCoordinate = nil
                // Remove existing annotations from the map
                self.Map.removeAnnotations(self.Map.annotations)
            }))
            present(alertController, animated: true, completion: nil)
        }
    }




